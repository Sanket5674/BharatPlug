package com.vst.bharatplug

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
