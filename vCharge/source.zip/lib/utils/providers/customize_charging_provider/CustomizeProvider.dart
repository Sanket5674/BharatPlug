import 'package:flutter/material.dart';

class CustomizeProvider with ChangeNotifier {
  int currentIndex = 0;
  int get itemIndex => currentIndex;

  void setIndex(index) {
    currentIndex = index;
    notifyListeners();
  }

  int time = 0;
  int get timeLimit => time;

  void setTime(time) {
    time = time;
    notifyListeners();
  }

  int unit = 0;
  int get unitLimit => unit;

  void setUnit(unit) {
    unit = unit;
    notifyListeners();
  }

  int money = 0;
  int get moneyLimit => money;

  void setMoney(money) {
    money = money;
    notifyListeners();
  }

  int timeSelected = 0;
  int get timeSelectedLimit => timeSelected;

  void setTimeSelect(timeSelected) {
    timeSelected = timeSelected;
    notifyListeners();
  }

  int unitSelected = 0;
  int get unitSelectedLimit => unitSelected;

  void setUnitSelect(unitSelected) {
    unitSelected = unitSelected;
    notifyListeners();
  }

  double moneySelected = 0;
  double get moneySelectedLimit => moneySelected;

  void setMoneySelect(moneySelected) {
    moneySelected = moneySelected;
    notifyListeners();
  }
}
