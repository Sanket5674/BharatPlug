import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:vcharge/services/GetMethod.dart';
import 'package:vcharge/view/addVehicleScreen/addVehicle.dart';
import 'package:vcharge/view/myVehicleScreen/widgets/showVehilcleDetailsPopup.dart';

import '../../models/addVehicleModel.dart';
import '../../services/urls.dart';
import '../components.dart';
import '../connectivity_service.dart';

// ignore: must_be_immutable
class MyVehicleScreen extends StatefulWidget {
  String userId;
  MyVehicleScreen({required this.userId, super.key});

  @override
  State<StatefulWidget> createState() => MyVehicleScreenState();
}

class MyVehicleScreenState extends State<MyVehicleScreen> {
  final ConnectivityService _connectivityService = ConnectivityService();

  //this list stores the list of vehicleModel objects
  // List<VehicleModel> vehicleList = [];

  //Initializing the list manually for demo purpose
  List<AddVehicleModel> vehicleList = [];

  @override
  void initState() {
    super.initState();
    getVehicleData();
    _checkConnectivity();
  }

  Future<void> _checkConnectivity() async {
    final connectivityResult = await _connectivityService.checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      // ignore: use_build_context_synchronously
      await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('No Internet Connection'),
            content: const Text(
                'Please check your internet connection and try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );

      const snackBar = SnackBar(
        content: Text('No internet connection'),
      );
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      return;
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> getVehicleData() async {
    const storage = FlutterSecureStorage();
    final userId = await storage.read(key: 'userId');
    try {
      var data = await GetMethod.getRequest(context,
          '${Urls().baseUrl}8097/manageUser/getVehicleByUserId?userId=$userId');
      setState(() {
        if (data != null) {
          for (int i = 0; i < data.length; i++) {
            vehicleList.add(AddVehicleModel.fromJson(data[i]));
          }
        }
      });
    } catch (e) {
      Components().showSnackbar(Components().something_want_wrong, context);
      print(e);
    }
  }
  var refreshkey = GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Vehicle'),
      ),
      body: vehicleList.isEmpty
          ? Center(
        child: TweenAnimationBuilder(
          duration: const Duration(seconds: 2),
          tween: Tween(begin: 0.0, end: 1.0),
          builder: (context, value, _) => SizedBox(
            height: 40,
            width: 40,
            child: CircularProgressIndicator(
              value: value,
              color: Components.lightGreen,
              backgroundColor: Components.white,
              strokeWidth: 5,
            ),
          ),
        ),
      )
          : RefreshIndicator(
        key: refreshkey,
        onRefresh: ()async{setState(() {
          _checkConnectivity();
          getVehicleData();
        });
        print("refresh");
        },
            child: ListView.builder(
                itemCount: vehicleList.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return ShowVehicleDetailsPopup(
                                vehicleDetails: vehicleList[index],
                                onDelete: (deletedVehicle) {
                                  setState(() {
                                    vehicleList.remove(deletedVehicle);
                                  });
                                });
                          });
                    },
                    child: Card(
                      elevation: 5,
                      color: const Color.fromARGB(255, 246, 249, 252),
                      child: Row(
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          //Container for Car Image
                          Expanded(
                            flex: 2,
                            child: Container(
                                margin: const EdgeInsets.all(5.0),
                                child: Image.asset('assets/images/demoCar.png')),
                          ),

                          // Container for Car Details
                          Expanded(
                            //we used expanded because the few texts was giving renderFlow error
                            flex: 2,
                            child: Container(
                              margin: const EdgeInsets.all(5.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // text car nick name
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 3, bottom: 5),
                                    child: Text(
                                      ' ${vehicleList[index].vehicleModelName}',
                                      style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 3, bottom: 5),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            '${vehicleList[index].vehicleBrandName} ${vehicleList[index].vehicleModelName} ${vehicleList[index].vehicleClass} ',
                                            style: const TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  //Container for vehicle adaptor type
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 3, bottom: 3),
                                    child: Text(
                                      'Connector Type: ${vehicleList[index].vehicleConnectorType}',
                                      style: const TextStyle(
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),

                                  //Container for vehicle battery capacity
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 3, bottom: 3),
                                    child: Text(
                                      'Battery Capacity: ${vehicleList[index].vehicleBatteryCapacity}',
                                      style: const TextStyle(
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
          ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => AddVehicleScreen(
                      userId: widget.userId,
                    )),
          );
        },
        label: const Text(
          'Add Vehicle',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
