import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:vcharge/services/DeleteMethod.dart';

import '../../../models/addVehicleModel.dart';
import '../../../services/urls.dart';
import '../../components.dart';

class ShowVehicleDetailsPopup extends StatelessWidget {
  //Initialize the VehicleModel object
  final AddVehicleModel vehicleDetails;
  final Function onDelete; // Add this line

  const ShowVehicleDetailsPopup({
    Key? key,
    required this.vehicleDetails,
    required this.onDelete, // Add this line
  }) : super(key: key);

  Future<void> deleteVehicleData(BuildContext context) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete this vehicle?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                final storage = FlutterSecureStorage();
                final userId = await storage.read(key: 'userId');
                try {
                  await DeleteMethod.deleteRequest(context,
                      '${Urls().baseUrl}8097/manageUser/removeVehicle?userId=$userId&vehicleId=${vehicleDetails.vehicleId}');
                  // Call the onDelete callback to update the list in MyVehicleScreen
                  onDelete(vehicleDetails);
                } catch (e) {
                  Components().showSnackbar(Components().something_want_wrong, context);
                  print(e);
                }

                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          //GestureDetector for back button
          GestureDetector(
            onTap: () {
              Navigator.of(context).pop();
            },
            child:
                const CircleAvatar(radius: 15, child: Icon(Icons.arrow_back)),
          ),

          GestureDetector(
              onTap: () {
                deleteVehicleData(context);
              },
              child: const CircleAvatar(
                  backgroundColor: const Color.fromARGB(255, 246, 249, 252),
                  radius: 15,
                  child: Icon(Icons.delete, color: Colors.red))),
        ],
      ),
      content: Wrap(
        children: [
          SizedBox(
            child: Image.asset('assets/images/demoCar.png'),
          ),

          const SizedBox(
            height: 10,
            width: 1,
          ),

          //Container for Vehicle Name
          Container(
            margin:
                const EdgeInsets.only(top: 10, bottom: 10, left: 1, right: 1),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                //We have added expanded in text because, if text get renderFlow error, so expanded can adjust it
                const Expanded(
                  child: Text(
                    'Vehicle',
                    style: TextStyle(fontSize: 14),
                  ),
                ),
                Expanded(
                    child: Text(
                  '${vehicleDetails.vehicleBrandName} ${vehicleDetails.vehicleModelName} ${vehicleDetails.vehicleClass}',
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.end,
                ))
              ],
            ),
          ),

          //Container for Battery Capacity
          Container(
            margin:
                const EdgeInsets.only(top: 10, bottom: 10, left: 1, right: 1),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                //We have added expanded in text because, if text get renderFlow error, so expanded can adjust it
                const Expanded(
                  child: Text(
                    'Battery Capacity',
                    style: TextStyle(fontSize: 14),
                  ),
                ),
                Expanded(
                    child: Text(
                  '${vehicleDetails.vehicleBatteryCapacity}',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 14),
                  textAlign: TextAlign.end,
                ))
              ],
            ),
          ),

          //Container for Battery Capacity
          Container(
            margin:
                const EdgeInsets.only(top: 10, bottom: 10, left: 1, right: 1),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                //We have added expanded in text because, if text get renderFlow error, so expanded can adjust it
                const Expanded(
                  child: Text(
                    'Connector Type',
                    style: TextStyle(fontSize: 14),
                  ),
                ),
                Expanded(
                    child: Text(
                  '${vehicleDetails.vehicleAdaptorType}',
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.end,
                ))
              ],
            ),
          ),

          const SizedBox(
            width: 1,
            height: 10,
          ),
        ],
      ),
    );
  }
}
