import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../../services/urls.dart';

class ManufacturerSelectionWidget extends StatefulWidget {
  final String userId;
  final String selectedVehicleType;
  final Function(String?) onSelectManufacturer;

  ManufacturerSelectionWidget({
    required this.userId,
    required this.selectedVehicleType,
    required this.onSelectManufacturer,
  });

  @override
  _ManufacturerSelectionWidgetState createState() =>
      _ManufacturerSelectionWidgetState();
}

class _ManufacturerSelectionWidgetState
    extends State<ManufacturerSelectionWidget> {
  late List<String> displayedManufacturers = [];

  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchManufacturers().then((manufacturers) {
      setState(() {
        displayedManufacturers = manufacturers;
      });
    });
  }

  Future<List<String>> fetchManufacturers() async {
    final apiUrl =
        '${Urls().baseUrl}8123/manageVehicle/getAllBrandNameByVehicleType?vehicleType=${widget.selectedVehicleType}';
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);

      if (data.isNotEmpty && data[0] is String) {
        return List<String>.from(data);
      }
    }

    throw Exception('Failed to load manufacturers');
  }

  void _selectCarModel(BuildContext context, String manufacturer) async {
    widget.onSelectManufacturer(manufacturer);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Center(
              child: Text(
                'Vehicle Details',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
          ),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            margin: EdgeInsets.all(16),
            elevation: 5,
            color: const Color.fromARGB(255, 246, 249, 252),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(2, 3),
                      ),
                    ],
                  ),
                  child: TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      labelText: 'Search Manufacturers',
                      prefixIcon: Icon(Icons.search),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                Container(
                  height: 450,
                  child: ListView.builder(
                    itemCount: displayedManufacturers.length,
                    itemBuilder: (context, index) {
                      final manufacturer = displayedManufacturers[index];
                      return Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.green),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        margin:
                            EdgeInsets.symmetric(vertical: 5, horizontal: 16),
                        child: ListTile(
                          title: Text(manufacturer),
                          onTap: () {
                            _selectCarModel(context, manufacturer);
                          },
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
