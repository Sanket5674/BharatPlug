import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_svg/svg.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:vcharge/models/chargingHistoryModel.dart';
import 'package:vcharge/models/stationModel.dart';
import 'package:vcharge/view/ChargingHistory/Widgets/ChargingHistoryDetailsPopUp.dart';

import '../../services/urls.dart';
import '../connectivity_service.dart';

class ChargingHistoryScreen extends StatefulWidget {
  @override
  _ChargingHistoryScreenState createState() => _ChargingHistoryScreenState();
}

class _ChargingHistoryScreenState extends State<ChargingHistoryScreen> {
  List<ChargingHistoryModel> chargingHistoryList = [];
  final ConnectivityService _connectivityService = ConnectivityService();

  Future<void> fetchData() async {
    final storage = FlutterSecureStorage();
    final userId = await storage.read(key: 'userId');
    final url = Uri.parse(
        '${Urls().baseUrl}8103/manageTransaction/getTransactions?transactionCustomerId=$userId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        chargingHistoryList = List<ChargingHistoryModel>.from(
            data.map((json) => ChargingHistoryModel.fromJson(json)));
      });
    } else {
      print('Failed to load data from the API');
    }
  }

  Future<StationModel> fetchStationDetails(String stationId) async {
    final stationDetailsUrl = Uri.parse(
        '${Urls().baseUrl}8096/manageStation/getStation?stationId=$stationId');
    final stationDetailsResponse = await http.get(stationDetailsUrl);

    if (stationDetailsResponse.statusCode == 200) {
      final stationDetails =
          StationModel.fromJson(json.decode(stationDetailsResponse.body));
      return stationDetails;
    } else {
      // Handle the error or return a default StationModel
      return StationModel();
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();

    _checkConnectivity();
  }

  Future<void> _checkConnectivity() async {
    final connectivityResult = await _connectivityService.checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('No Internet Connection'),
            content:
                Text('Please check your internet connection and try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );

      final snackBar = SnackBar(
        content: Text('No internet connection'),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      return;
    }
  }
  var refreshkey = GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Charging History'),
      ),
      body: chargingHistoryList.isEmpty
          ? Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(
                          top: MediaQuery.of(context).size.width * 0.08),
                      height: MediaQuery.of(context).size.height * 0.32,
                      child: SvgPicture.asset('assets/images/NoData.svg'),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          top: MediaQuery.of(context).size.height * 0.03),
                      child: Text(
                        " No Data Available!",
                        style: TextStyle(
                            fontSize: Get.height * 0.02,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ]),
            )
          : RefreshIndicator(
        key: refreshkey,
        onRefresh: ()async{setState(() {
          fetchData();
          _checkConnectivity();
        });
        print("refresh");
        },
            child: ListView.builder(
                itemCount: chargingHistoryList.length,
                itemBuilder: (context, index) {
                  final chargingHistory = chargingHistoryList[index];

                  return FutureBuilder<StationModel>(
                    future: fetchStationDetails(
                        chargingHistory.transactionStationId ?? ''),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.done) {
                        final stationDetails = snapshot.data ?? StationModel();
                        final startTime = DateTime.tryParse(
                            chargingHistory.transactionMeterStartTimeStamp ?? "");
                        final stopTime = DateTime.tryParse(
                            chargingHistory.transactionMeterStopTimeStamp ?? "");

                        if (startTime != null && stopTime != null) {}
                        return InkWell(
                          onTap: () {
                            showModalBottomSheet(
                              context: context,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20)),
                              ),
                              builder: (context) {
                                return ChargingHistoryDetailsPopUp(
                                  transactionDetails: chargingHistory,
                                  stationDetails: stationDetails,
                                );
                              },
                            );
                          },
                          child: Card(
                              elevation: 3,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              color: const Color.fromARGB(255, 246, 249, 252),
                              margin: EdgeInsets.symmetric(
                                  horizontal: Get.width * 0.02,
                                  vertical: Get.height * 0.01),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          '${stationDetails.stationName}',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        Card(
                                            color: const Color.fromARGB(
                                                255, 246, 249, 252),
                                            elevation: 0,
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  vertical: Get.height * 0.004,
                                                  horizontal: Get.width * 0.015),
                                              child: Text(
                                                '${chargingHistory.transactionAmount} Rs.',
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )),
                                      ],
                                    ),

                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        //Column booking status
                                        Expanded(
                                          child: SizedBox(
                                            height: Get.height * 0.07,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Text(
                                                  'Transaction Status',
                                                  style: TextStyle(
                                                      fontSize: Get.width * 0.035,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                Card(
                                                    elevation: 0,
                                                    color: Color.fromARGB(
                                                        255, 221, 243, 222),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical:
                                                                  Get.height *
                                                                      0.004,
                                                              horizontal:
                                                                  Get.width *
                                                                      0.015),
                                                      child: Text(
                                                        chargingHistory
                                                                    .transactionStatus ==
                                                                "EVDisconnected"
                                                            ? "Fully charged or Disconnected"
                                                            : chargingHistory
                                                                .transactionStatus!,
                                                        maxLines: 1,
                                                        overflow:
                                                            TextOverflow.ellipsis,
                                                        style: TextStyle(
                                                            fontSize:
                                                                Get.width * 0.03),
                                                      ),
                                                    ))
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),

                                    //Wrap for amount paid
                                    Container(
                                      margin: EdgeInsets.symmetric(
                                          vertical: Get.height * 0.004),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          //Row for amount paid

                                          Container(
                                            margin: EdgeInsets.symmetric(
                                                vertical: Get.height * 0.004),
                                            child: Wrap(
                                              spacing: 20,
                                              children: [
                                                Text(
                                                    DateFormat("dd MMM, yyyy")
                                                        .format(DateTime.parse(
                                                      '${chargingHistory.transactionMeterStartTimeStamp}',
                                                    )),
                                                    style: TextStyle(
                                                      fontWeight: FontWeight.bold,
                                                    )),
                                                Text(
                                                    "${DateFormat("hh:mm a ").format(DateTime.parse(chargingHistory.transactionMeterStartTimeStamp!))}-${DateFormat(" hh:mm a ").format(DateTime.parse(chargingHistory.transactionMeterStopTimeStamp!))}",
                                                    style: TextStyle(
                                                      fontWeight: FontWeight.bold,
                                                    )),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )),
                        );
                      } else {
                        return Center(child: CircularProgressIndicator());
                      }
                    },
                  );
                },
              ),
          ),
    );
  }
}

void main() {
  runApp(
    MaterialApp(
      home: ChargingHistoryScreen(),
    ),
  );
}
