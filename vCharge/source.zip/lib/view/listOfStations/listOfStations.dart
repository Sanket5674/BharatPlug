import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:latlng/latlng.dart';
import 'package:vcharge/models/chargerModel.dart';
import 'package:vcharge/models/connectorModel.dart';
import 'package:vcharge/models/stationModel.dart';
import 'package:vcharge/services/getLiveLocation.dart';
import 'package:vcharge/services/getMethod.dart';
import 'package:vcharge/utils/availabilityColorFunction.dart';
import 'package:vcharge/view/homeScreen/widgets/bgMap.dart';
import 'dart:math' as Math;
import 'package:vcharge/view/connectivity_service.dart';
import 'package:vcharge/view/listOfStations/widgets/searchBarOfLOS.dart';
import 'package:vcharge/view/stationsSpecificDetails/stationsSpecificDetails.dart';

import '../../services/urls.dart';
import '../components.dart';

// ignore: must_be_immutable
class ListOfStations extends StatefulWidget {
  String userId;

  ListOfStations({required this.userId, super.key});

  @override
  State<StatefulWidget> createState() => ListOfStationsState();
}

class ListOfStationsState extends State<ListOfStations> {
  final ConnectivityService _connectivityService = ConnectivityService();
  static List<RequiredStationDetailsModel> stationsData = [];
  static List<RequiredStationDetailsModel> matchingStations = [];
  //stores current location of user
  LatLng? userPosition;

  String getStationUrl =
      '${Urls().baseUrl}8096/manageStation/getStationInterface';

  @override
  void initState() {
    super.initState();
    // getStationList();
    getLocationOfUser();
    _checkConnectivity();
    if (mounted) {
      sortStationList();
    }
  }

  static void updateFilters(context, Map<String, dynamic> filters) {

    stationsData = sortedStationList;
    print("stationData : ${stationsData.length}");
    String? station = filters['stationMode'];                 //
    String? charger = filters['showAvailableChargersOnly'];   //
    String? chargerType= filters['chargerType'];              //
    List? connectorType= filters['selectedConnectorType'];    //
    // matchingStations.clear();

    getFilter(station,charger,chargerType,connectorType);

    BgMapState.getMarkersDetails(context, matchingStations);

    print("stationsData ${stationsData.length}");
    print("matchingStations ${matchingStations.length}");
  }
  static getFilter(String? stationAccessType, String? chargerAvailability , String? chargerType ,List? connectorType ){
    print("testing data  ========== $stationAccessType $chargerAvailability $chargerType $connectorType");
    //     testing data  ==========      Public           Available           DC             [CHAdeMO]
    matchingStations.clear();
    stationsData.forEach((singleStation) {
      if(stationAccessType == singleStation.stationParkingType || stationAccessType == null){
        singleStation.chargers!.length !=0 ? singleStation.chargers!.forEach((singleCharger) {
          if((singleCharger.chargerStatus == chargerAvailability || chargerAvailability == null) && (singleCharger.chargerType == chargerType || chargerType==null)){

            singleCharger.connectors!.length != 0 ? singleCharger.connectors!.forEach((singleConnector) {
              connectorType != null ? connectorType.forEach((type) {
                if((singleConnector.connectorType==type) || type == null){
                  print(" if wale  stationParkingType : ${singleStation.stationParkingType} chargerStatus : ${singleCharger.chargerStatus}  chargerType : ${singleCharger.chargerType}"); //connectorType : ${singleConnector.connectorType} ");
                  // matchingStations.add(singleStation);
                  checkList(singleStation);
                }
              }) :connectorType ==null? checkList(singleStation):print("nothing"); // matchingStations.add(singleStation)

            }): connectorType ==null? checkList(singleStation):print("nothing");
          }
        }): chargerAvailability == null && chargerType == null && connectorType==null ? checkList(singleStation):print("nothing");
      }
    });


    sortedStationList = matchingStations;
    print("matchingStations : ${matchingStations.length}");
  }


  Future<void> _checkConnectivity() async {
    final connectivityResult = await _connectivityService.checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('No Internet Connection'),
            content: const Text(
                'Please check your internet connection and try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Retry'),
              ),
            ],
          );
        },
      );

      final snackBar = const SnackBar(
        content: Text('No internet connection'),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      return;
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  //this list store the list of stations
  List<RequiredStationDetailsModel> stationsList = [];

  List<ConnectorModel> connectorList = [];
  List<ChargerModel> chargerList = [];

  //this list store the distance for user to each station
  List<double> userToStationDistanceList = [];

  //this list store the list of station and distance
  static List<Map<String, dynamic>> sortedStationDistanceList = [];

  //this list container the list of sorted station
  static List<RequiredStationDetailsModel> sortedStationList = [];

  //this list container the list of sorted distance according to station
  static List<double> sortedDistanceList = [];
  static List<ConnectorModel> connectorsList = [];

  //get current location of the user
  Future<void> getLocationOfUser() async {
    try {
      userPosition = LatLng(BgMapState.userLocation!.latitude,
          BgMapState.userLocation!.longitude);
    } catch (e) {
      var position = await GetLiveLocation.getUserLiveLocation();
      if (mounted) {
        setState(() {
          userPosition = LatLng(position.latitude, position.longitude);
        });
      }
    }
  }

  Future<void> getStationList(BuildContext context,String url) async {
    try {
      var data = await GetMethod.getRequest(context,url);
      if (data.isNotEmpty) {
        stationsList.clear();
        for (int i = 0; i < data.length; i++) {
          stationsList.add(RequiredStationDetailsModel.fromJson(data[i]));
        }
        if (mounted) {
          setState(() {
            print(" stationsList is tnos : $stationsList");
            // BgMapState.getMarkersDetails(context, stationsList);
          });
        }
      } else {
        print("Empty Data");
      }
    } catch (e) {
      Components().showSnackbar(Components().something_want_wrong, context);
      print(e);
    }
  }

  //To calculate the distance between two points on the Earth's surface given their latitude and longitude coordinates, you can use the Haversine formula.
  double getDistanceFromUser(LatLng latLng1, LatLng latLng2) {
    // convert decimal degrees to radians
    double lat1 = latLng1.latitude;
    double lon1 = latLng1.longitude;
    double lat2 = latLng2.latitude;
    double lon2 = latLng2.longitude;

    var R = 6371;
    var dLat = deg2rad(lat2 - lat1);
    var dLon = deg2rad(lon2 - lon1);
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(lat1)) *
            Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c;
    return d;
  }

  double deg2rad(deg) {
    return deg * (Math.pi / 180);
  }

  Future<void> getDistanceList() async {
    await getStationList(context,getStationUrl);

    userToStationDistanceList = stationsList.map((station) {
      return getDistanceFromUser(
          userPosition!, const LatLng(18.551980, 73.956610));
    }).toList();
  }

  Future<void> sortStationList() async {
    stationsList.clear();
    userToStationDistanceList.clear();
    sortedStationDistanceList.clear();
    sortedStationList.clear();
    sortedDistanceList.clear();

    await getDistanceList();
    sortedStationDistanceList = List.generate(
      stationsList.length,
      (index) => {
        'station': stationsList[index],
        'distance': userToStationDistanceList[index]
      },
    );

    sortedStationDistanceList
        .sort((a, b) => a['distance'].compareTo(b['distance']));
    if (mounted) {
      setState(() {
        for (int i = 0; i < sortedStationDistanceList.length; i++) {
          sortedStationList.add(sortedStationDistanceList[i]['station']);
          sortedDistanceList.add(sortedStationDistanceList[i]['distance']);
        }
      });
    }
    print("sortedStationDistanceList : ${sortedStationDistanceList[0]['stations']}");
  }

  String getConnectorImage(String? connectorType) {
    switch (connectorType?.toLowerCase()) {
      case 'ccs':
        return 'assets/images/CSSCombo.png';
      case 'chademo':
        return 'assets/images/CHAdeMO.png';
      case 'type 2':
        return 'assets/images/Type2.png';
      case 'type 1':
        return 'assets/images/Type1.png';
      default:
        return 'assets/images/Type1.png';
    }
  }
  var refreshkey = GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).unfocus();
            },
            child: Scaffold(
                appBar: AppBar(
                  centerTitle: true,
                  title: const Text('Stations'),
                ),
                body: SafeArea(
                    child: Wrap(
                          children: [
                                        Container(
                        margin: EdgeInsets.all(
                            MediaQuery.of(context).size.width * 0.04),
                        height: MediaQuery.of(context).size.height * 0.05,
                        child: SearchBarofLOS(
                          userId: widget.userId,
                        )),
                                        SizedBox(
                        height: MediaQuery.of(context).size.height * 0.73,
                        child: sortedStationList.isEmpty
                            ? Center(
                              child: TweenAnimationBuilder(
                                                      duration: const Duration(seconds: 2),
                                                      tween: Tween(begin: 0.0, end: 1.0),
                                                      builder: (context, value, _) => SizedBox(
                              height: 40,
                              width: 40,
                              child: CircularProgressIndicator(
                                value: value,
                                color: Components.lightGreen,
                                backgroundColor: Components.white,
                                strokeWidth: 5,
                              ),
                                                      ),
                                                    ),
                            )
                            :  RefreshIndicator(
                          key: refreshkey,
                          onRefresh: ()async{setState(() {
                            getLocationOfUser();
                            _checkConnectivity();
                            if (mounted) {
                              sortStationList();
                            }
                          });
                          print("refresh");
                          },
                          child: ListView.builder(
                                  itemCount: sortedStationList.length,
                                  itemBuilder: (context, index) {
                                    //print(".....");
                                    print(sortedStationList[index].chargers);
                                    return GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                StationsSpecificDetails(
                                              stationId: sortedStationList[index]
                                                  .stationId!,
                                              userId: widget.userId,
                                            ),
                                          ),
                                        );
                                      },
                                      child: Card(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          elevation: 4,
                                          margin: EdgeInsets.all(
                                            MediaQuery.of(context).size.width *
                                                0.03,
                                          ),
                                          child: Column(children: [
                                            ListTile(
                                              title: Text(
                                                sortedStationList[index]
                                                    .stationName!,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.04,
                                                ),
                                              ),
                                              subtitle: Text(
                                                sortedStationList[index]
                                                    .stationArea!,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              trailing: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.spaceEvenly,
                                                children: [
                                                  Wrap(
                                                    spacing: MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.02,
                                                    children: [
                                                      // ignore: unnecessary_null_comparison
                                                      sortedDistanceList[index] ==
                                                              null
                                                          ? const CircularProgressIndicator()
                                                          : Text(
                                                              '${sortedDistanceList[index].toStringAsFixed(2)} KM',
                                                              style:
                                                                  const TextStyle(
                                                                fontWeight:
                                                                    FontWeight.bold,
                                                              ),
                                                            ),
                                                      CircleAvatar(
                                                        radius:
                                                            MediaQuery.of(context)
                                                                    .size
                                                                    .width *
                                                                0.02,
                                                        backgroundColor:
                                                            AvaliblityColor
                                                                .getAvailablityColor(
                                                          sortedStationList[index]
                                                              .stationStatus!,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                            const Divider(
                                              color: Colors.grey,
                                              thickness: 1.0,
                                            ),
                                            if (sortedStationList[index].chargers !=
                                                    null &&
                                                sortedStationList[index]
                                                    .chargers!
                                                    .isNotEmpty)
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  for (var charger
                                                      in sortedStationList[index]
                                                          .chargers!)
                                                    if (charger.connectors !=
                                                            null &&
                                                        charger
                                                            .connectors!.isNotEmpty)
                                                      for (var connector
                                                          in charger.connectors!)
                                                        ListTile(
                                                          leading: CircleAvatar(
                                                            radius: 20.0,
                                                            backgroundImage: AssetImage(
                                                                getConnectorImage(
                                                                    connector
                                                                        .connectorType)),
                                                          ),
                                                          title: Text(
                                                            '${connector.connectorType}',
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight.w500,
                                                              fontSize: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  0.04,
                                                            ),
                                                          ),
                                                          subtitle: Text(
                                                            '${connector.connectorSocket}',
                                                            maxLines: 1,
                                                            overflow: TextOverflow
                                                                .ellipsis,
                                                          ),
                                                          trailing: Row(
                                                            mainAxisSize:
                                                                MainAxisSize.min,
                                                            children: [
                                                              if (connector
                                                                      .connectorStatus ==
                                                                  'Available')
                                                                const Text(
                                                                  'Available',
                                                                  style: TextStyle(
                                                                    color: Colors
                                                                        .green,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                              if (connector
                                                                      .connectorStatus ==
                                                                  'Unavailable')
                                                                const Text(
                                                                  'Unavailable',
                                                                  style: TextStyle(
                                                                    color:
                                                                        Colors.red,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                              Icon(
                                                                Icons
                                                                    .keyboard_arrow_right,
                                                                size: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.07,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                ],
                                              ),
                                          ])),
                                    );
                                  }),
                            ))
                                      ]),
                    ))));
  }

  static checkList(RequiredStationDetailsModel singleStation) {

    matchingStations.length != 0 ? matchingStations.addIf(!matchingStations.contains(singleStation), singleStation):matchingStations.add(singleStation);
  }
}
