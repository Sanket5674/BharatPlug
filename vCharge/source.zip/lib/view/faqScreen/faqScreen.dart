import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../services/urls.dart';
import '../components.dart';
import '../connectivity_service.dart';

class FaqScreen extends StatefulWidget {
  const FaqScreen({super.key});

  @override
  FaqScreenState createState() => FaqScreenState();
}

class FaqScreenState extends State<FaqScreen> {
  final ConnectivityService _connectivityService = ConnectivityService();

  // variable for by default selecting the general property
  String selectedCategory = 'General';

  // list of dynamic data type for storing the FAQ's
  List<dynamic> faqs = [];

  // function for fetching up all the faqs and storing it in the FAQ list
  Future<void> getFaqs() async {
    var response =
        await http.get(Uri.parse('${Urls().baseUrl}8098/manageFaq/faqs'));

    if (response.statusCode == 200) {
      setState(() {
        faqs = json.decode(response.body);
      });
    } else {
      throw Exception('Failed to load FAQs');
    }
  }

  // initstate method which calls the getFaqs() method so that it can fetch all the faq's
  @override
  void initState() {
    super.initState();
    getFaqs();

    _checkConnectivity();
  }

  Future<void> _checkConnectivity() async {
    final connectivityResult = await _connectivityService.checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('No Internet Connection'),
            content: const Text(
                'Please check your internet connection and try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );

      final snackBar = const SnackBar(
        content: Text('No internet connection'),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      return; // Return early to avoid the rest of the code
    }
// The rest of your logic (e.g., loading station data) can go here
  }

  @override
  void dispose() {
    super.dispose();
  }

  // build method
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("FAQ"),
        centerTitle: true,
      ),

      // column has two children:
      body: Column(
        children: [
          // toggle buttons - first child
          Container(
            height: 60,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (var category in [
                    'General',
                    'Charger',
                    'Payment and refund',
                    'Troubleshooting and Maintenance'
                  ])
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            selectedCategory = category;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          primary: selectedCategory == category
                              ? Colors.green
                              : Colors.white, // Background color
                          side: const BorderSide(
                            color: Colors.green, // Green border for all buttons
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                        child: Text(
                          category,
                          style: TextStyle(
                            color: selectedCategory == category
                                ? Colors.white
                                : Colors.green, // Text color
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),

          // questions and answers - second child
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              itemCount: faqs
                  .where((faq) => faq['faqCategory'] == selectedCategory)
                  .length,
              itemBuilder: (BuildContext context, int index) {
                // var sortedFaqs = faqs.where((faq) => faq['faqCategory'] == selectedCategory).toList()
                //   ..sort((faq1, faq2) => double.parse(faq1['faqSeqNumber']).compareTo(double.parse(faq2['faqSeqNumber'])));
                // ..sort((faq1, faq2) => int.parse(faq1['faqSeqNumber']).compareTo(int.parse(faq2['faqSeqNumber'])));

                var sortedFaqs;
                var faq;

                // block for sorting the specific category faq on the basis of the faq sequence number
                try {
                  sortedFaqs = faqs
                      .where((faq) => faq['faqCategory'] == selectedCategory)
                      .toList()
                    ..sort((faq1, faq2) =>
                        faq1['faqSeqNumber'].compareTo(faq2['faqSeqNumber']));
                  faq = sortedFaqs[index];
                } catch (e) {
                  Components().showSnackbar(Components().something_want_wrong, context);
                  print("The error is in the faq: $e");
                }

                return Theme(
                  data: Theme.of(context).copyWith(
                    dividerColor: Colors.transparent,
                  ),
                  child: Container(
                    margin: const EdgeInsets.all(10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.green,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ExpansionTile(
                      title: Text(faq['faqQuestion']),
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(faq['faqAnswer']),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
