import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:vcharge/services/GetMethod.dart';
import 'package:vcharge/utils/availabilityColorFunction.dart';
import 'package:vcharge/view/stationsSpecificDetails/stationsSpecificDetails.dart';

import '../../models/stationModel.dart';
import '../../services/urls.dart';
import '../components.dart';

// ignore: must_be_immutable
class FavouriteSceen extends StatefulWidget {
  String userId;
  FavouriteSceen({required this.userId, super.key});

  @override
  State<StatefulWidget> createState() => FavouriteSceenState();
}

class FavouriteSceenState extends State<FavouriteSceen> {
  List<FovouriteStationDetailsModel> favouriteList = [];
  bool isFavourite = false;

  Future<void> getFavouriteList() async {
    try {
      final storage = FlutterSecureStorage();
      final userId = await storage.read(key: 'userId');
      var data = await GetMethod.getRequest(context,
          '${Urls().baseUrl}8097/manageUser/getFavoritesByUserId?userId=$userId');
      if (data != null && data.isNotEmpty) {
        favouriteList.clear();
        setState(() {
          for (int i = 0; i < data.length; i++) {
            favouriteList.add(FovouriteStationDetailsModel.fromJson(data[i]));
          }
        });
      }
    } catch (e) {
      Components().showSnackbar(Components().something_want_wrong, context);
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();
    getFavouriteList();
  }
  var refreshkey = GlobalKey<RefreshIndicatorState>();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: AppBar(
              centerTitle: true,
              title: const Text('Favourites'),
            ),
            body: favouriteList.isEmpty
                ? Center(
              child: TweenAnimationBuilder(
                duration: const Duration(seconds: 2),
                tween: Tween(begin: 0.0, end: 1.0),
                builder: (context, value, _) => SizedBox(
                  height: 40,
                  width: 40,
                  child: CircularProgressIndicator(
                    value: value,
                    color: Components.lightGreen,
                    backgroundColor: Components.white,
                    strokeWidth: 5,
                  ),
                ),
              ),
            )
                : RefreshIndicator(
              key: refreshkey,
              onRefresh: ()async{setState(() {
                getFavouriteList();
              });
              print("refresh");
              },
                  child: ListView.builder(
                      itemCount: favouriteList.length,
                      itemBuilder: (contexr, index) {
                        return InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => StationsSpecificDetails(
                                        userId: widget.userId,
                                        stationId:
                                            favouriteList[index].stationId ??
                                                "")));
                          },
                          child: Card(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8)),
                            elevation: 5,
                            margin: EdgeInsets.symmetric(
                                vertical: Get.width * 0.02,
                                horizontal: Get.width * 0.04),
                            color: const Color.fromARGB(255, 246, 249, 252),
                            child: Padding(
                                padding: EdgeInsets.all(Get.width * 0.01),
                                child: Padding(
                                  padding: EdgeInsets.all(Get.width * 0.02),
                                  child: Row(children: [
                                    Expanded(
                                      flex: 8,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          //station Name
                                          Padding(
                                            padding: EdgeInsets.symmetric(
                                                vertical: Get.height * 0.002),
                                            child: Text(
                                              favouriteList[index].stationName ??
                                                  "",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: Get.width * 0.045),
                                            ),
                                          ),

                                          //station address
                                          Padding(
                                            padding: EdgeInsets.symmetric(
                                                vertical: Get.height * 0.008),
                                            child: Text(
                                              '${favouriteList[index].stationArea ?? ""}',
                                              maxLines: 2,
                                              style: const TextStyle(
                                                  color: Color.fromARGB(
                                                      255, 132, 132, 132)),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    //Column for station Status and number of chargers
                                    Expanded(
                                        flex: 4,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            //station status
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                  vertical: Get.height * 0.008),
                                              child: CircleAvatar(
                                                radius: 8,
                                                backgroundColor: AvaliblityColor
                                                    .getAvailablityColor(
                                                        favouriteList[index]
                                                                .stationStatus ??
                                                            ""),
                                              ),
                                            ),

                                            //station number of chargers
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                  vertical: Get.height * 0.008),
                                              child: const Text(
                                                'Chargers: 2/3',
                                                style: TextStyle(
                                                    color: Colors.grey,
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )
                                          ],
                                        )),
                                  ]),
                                )),
                          ),
                        );
                      },
                    ),
                )));
  }
}
