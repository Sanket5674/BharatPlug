class Message{
    
    final String text;
    final DateTime date;
    final bool isSentByMe;

    const Message({

      required this.text,
      required this.date,
      required this.isSentByMe,

    });

}