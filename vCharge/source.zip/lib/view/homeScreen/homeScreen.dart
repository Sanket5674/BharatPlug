import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:upgrader/upgrader.dart';
import 'package:vcharge/view/homeScreen/existingHomeScreen.dart';

import 'package:vcharge/view/homeScreen/widgets/sideBarDrawer.dart';
import 'package:vcharge/view/listOfStations/listOfStations.dart';
import 'package:vcharge/view/qrScanner.dart/scanner.dart';

import '../../services/notificationService.dart';

class HomeScreen extends StatefulWidget {
  final Login? login;
  const HomeScreen({Key? key, this.login}) : super(key: key);

  @override
  HomeScreenState createState() => HomeScreenState();
}

class Login {
  final String username;
  final String password;

  Login(this.username, this.password);
}

class HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
/*

keep this code for future reference:


this is screen with onclose function
      FilterPopUp(onClose: () {
              selectedIndex = 0;
              isFilterOpen = false;
            setState(() {
              print("inside the setstate function of the filterpopup");
            });
          }), 


 this is ontap of curvednavigation bar
        onTap: (index) {
            print("index is: $index");
            if (index == 3) {
          isFilterOpen = true;
        } else {
          isFilterOpen = false;         
        }
            selectedIndex = index;

            print("Selected index is: $selectedIndex");
            setState(() {
              // isFilterOpen = false;
            });
          }


    */

  //this the user ID of the current user who is logged in
  static String userId = "";
  final storage = FlutterSecureStorage();
  getUserId() async {
    userId = (await storage.read(key: 'userId'))!;
    TRNID =  await storage.read(key: "TRNID");
    print("this is userId: $userId");
  }
  String? TRNID;

  @override
  void initState() {
    getUserId();
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }
  NotificationService notificationService = NotificationService();
  @override
  void didChangeAppLifecycleState(AppLifecycleState state)async {
    super.didChangeAppLifecycleState(state);

      switch (state) {
        case AppLifecycleState.resumed:
          print("app in resumed");
          break;
        case AppLifecycleState.inactive:
          print("app in inactive");
          break;
        case AppLifecycleState.paused:
          if(TRNID != null){
          notificationService.initializeNotification();
          notificationService.sendNotification(context,
              "Bharat Plug is charging your vehicle...", "thanks for connect us");}
          print("app in paused");
          break;
        case AppLifecycleState.detached:
          print("app in detached");
          break;
        case AppLifecycleState.hidden:
          print("app in hidden");
          break;
      }
    }



  int selectedIndex = 1;

  final GlobalKey<CurvedNavigationBarState> bottomNavBarKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
// screens
    List<dynamic> screens = [
      Semantics(
          label: "listOfStationPage",
          value: 'listOfStationPage',
          child: ListOfStations(
            userId: userId,
          )),
      Semantics(
        label: "homePage",
        value: "homePage",
        child: ExistingHomeScreen(
          userId: userId,
        ),
      ),
      Semantics(
          label: "scannerPage",
          value: "scannerPage",
          child: QRScannerWidget(
            userId: userId,
          )),
    ];

// bottom bar icons
    final items = <Widget>[
      Icon(Icons.list,
          size: 30, color: selectedIndex == 0 ? Colors.white : Colors.white),
      Icon(Icons.home,
          size: 30, color: selectedIndex == 1 ? Colors.white : Colors.white),
      Icon(Icons.qr_code_scanner,
          size: 30, color: selectedIndex == 2 ? Colors.white : Colors.white),
    ];

    return WillPopScope(
        onWillPop: () async {
          if (selectedIndex != 1) {
            // if not on home screen, navigate to home screen and return false
            setState(() {
              selectedIndex = 1;
            });
            return false;
          } else {
            // if on home screen, allow back button press to close the app
            return true;
          }
        },
        child: Scaffold(
          // this variable is used to extend the background to the appbar
          extendBodyBehindAppBar: true,

          // this variable is used to extend the background to the bottombar
          extendBody: true,
          drawer: SideBarDrawer(userId: userId),
          // this is body
          body: UpgradeAlert(child: screens[selectedIndex]),

          // this is bottom bar
          bottomNavigationBar: CurvedNavigationBar(
              color: Colors.green,
              key: bottomNavBarKey,
              height: MediaQuery.of(context).size.height * 0.07,
              animationCurve: Curves.easeInOut,
              backgroundColor: Colors.transparent,
              buttonBackgroundColor: Colors.green,
              animationDuration: const Duration(milliseconds: 300),
              items: items,
              index: selectedIndex,
              onTap: (index) {
                if (Navigator.of(context).canPop()) {
                  Navigator.of(context).pop();
                }
                setState(() {
                  selectedIndex = index;
                });
              }),
        ));
  }
}
