/*

as you know, i have three buttons in the bottom navigation bar, default app opens at the index = 1 
button and at index = 0, there is a list of all stations page and index = 2, has the qr scanner
page. What i want is, when i am at the scanner page or say the list of all stations page, 
once user clicks the back button which comes by default on the android, it should come back to the home button
which is by default set and it should not terminate the application and close it.

*/
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:vcharge/models/transactionModel.dart';
import 'package:vcharge/services/GetMethod.dart';
import 'package:intl/intl.dart';
import 'package:vcharge/view/walletScreen/addMoneyScreen.dart';
import '../../models/transactionModelNew.dart';
import '../../models/walletModel.dart';
import '../../services/urls.dart';
import '../components.dart';

// ignore: must_be_immutable
class WalletScreen extends StatefulWidget {
  String? userId;

  WalletScreen({required this.userId, super.key});

  @override
  State<StatefulWidget> createState() => WalletScreenState();
}

class WalletScreenState extends State<WalletScreen> {
  // final ConnectivityService _connectivityService = ConnectivityService();

  WalletModel? walletDetail;
  double? walletAmount;
  bool? walletStatus;
  var currentMonth;
  List<TransactionModelNew> newTransactionData = [];
  List<TransactionModelNew> todayTransactionData = [];
  List<TransactionModelNew> weekTransactionData = [];
  List<TransactionModelNew> monthTransactionData = [];
  List<TransactionModelNew> yearTransactionData = [];
  List<TransactionModel> transactionData = [];
  bool credit = true;
  //user name
  var userFirstName = "...";
  var userLastName = "...";
  int day = 1;
  final storage = FlutterSecureStorage();
  @override
  void initState() {
    // getUserName();
    getWalletDetails();
    super.initState();
  }

  //fetch the wallet details according to userId and store it to walletDetail variable
  Future<void> getWalletDetails() async {
    try {
      final userId = await storage.read(key: 'userId');
      var data = await GetMethod.getRequest(context,
          "${Urls().baseUrl}8097/manageUser/getWalletByUserId?userId=${userId.toString()}");

      print("${data}");
      setState(() {
        walletAmount = data['walletAmount'] / 100;
        walletStatus = data['active'];
        // walletDetail = WalletModel(
        //     walletAmount: data['walletAmount'], walletStatus: data['active']);
      });
      print("${walletAmount.toString()}");
    } catch (e) {
      Components().showSnackbar(Components().something_want_wrong, context);
      print(e);
    }
  }

  Future<void> getTransaction() async {
    try {
      final userId = await storage.read(key: 'userId');
      var data = await GetMethod.getRequest(context,
          "${Urls().baseUrl}8103/manageTransaction/getTransactionAmounts?transactionCustomerId=${userId}");

      print("data : ${data}");
      setState(() {
        if (data != null) {
          for (int i = 0; i < data.length; i++) {
            newTransactionData.add(TransactionModelNew(
              transactionId: data[i]['transactionId'],
              transactionAmount: data[i]['transactionAmount'],
              chargerName: data[i]['chargerName'],
              transactionMeterStopTimeStamp: data[i]
                  ['transactionMeterStopTimeStamp'],
            ));
          }

          var now = new DateTime.now();
          var now_1m = new DateTime(now.year, now.month - 1, now.day);

          var todayDate = DateFormat('yyyy-MM-dd')
              .format(DateFormat('yyyy-MM-dd').parse("${now}"));

          var weekDate = DateFormat('yyyy-MM')
              .format(DateFormat('yyyy-MM').parse("${now}"));

          currentMonth = DateFormat('MMMM, y')
              .format(DateFormat('yyyy-MM').parse("${now}"));

          var monthDate =
              DateFormat('yyyy').format(DateFormat('yyyy').parse("${now_1m}"));

          for (int i = 0; i < data.length; i++) {
            // print("this is : ${DateFormat('yyyy-MM-dd')
            //     .format(
            //     DateFormat('yyyy-MM-dd').parse(
            //         "${newTransactionData[i].transactionMeterStopTimeStamp}"))}");

            var dateForCompareToday = DateFormat('yyyy-MM-dd').format(
                DateFormat('yyyy-MM-dd').parse(
                    "${newTransactionData[i].transactionMeterStopTimeStamp}"));

            var dateForCompareWeek = DateFormat('yyyy-MM').format(
                DateFormat('yyyy-MM').parse(
                    "${newTransactionData[i].transactionMeterStopTimeStamp}"));

            var dateForCompareMonth = DateFormat('yyyy').format(
                DateFormat('yyyy').parse(
                    "${newTransactionData[i].transactionMeterStopTimeStamp}"));

            todayDate == dateForCompareToday
                ? todayTransactionData.add(newTransactionData[i])
                : weekDate == dateForCompareWeek
                    ? weekTransactionData.add(newTransactionData[i])
                    : monthDate == dateForCompareMonth
                        ? monthTransactionData.add(newTransactionData[i])
                        : yearTransactionData.add(newTransactionData[i]);
          }
        }
      });
    } catch (e) {
      Components().showSnackbar(Components().something_want_wrong, context);
      print(e);
    }
  }

  //this function returns an icon based on given status
  IconData getStatusIcon(String status) {
    if (status.trim().toLowerCase() == 'complete') {
      return Icons.done;
    } else if (status.trim().toLowerCase() == 'pending') {
      return Icons.pending;
    } else {
      return Icons.cancel;
    }
  }

  //this function returns a color based on given status
  MaterialColor getStatusColor(String status) {
    if (status.trim().toLowerCase() == 'completed') {
      return Colors.green;
    } else if (status.trim().toLowerCase() == 'pending') {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }
  var refreshkey = GlobalKey<RefreshIndicatorState>();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          actions: [
            IconButton(onPressed: (){
              getWalletDetails();
            }, icon: Icon(Icons.refresh)),
          ],
          centerTitle: true,
          title: const Text('Wallet'),
        ),
        body: Wrap(
                children: [
                  Align(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          top: 30.0, bottom: 30, left: 15, right: 15),
                      child: Container(
                        height: 150,
                        width: 300,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black54,
                              blurRadius: 15.0,
                              spreadRadius: -20.0,
                              offset: Offset(0.0, 25.0),
                            )
                          ],
                          borderRadius: BorderRadius.circular(15),
                          gradient: LinearGradient(
                            colors: [
                              Color.fromARGB(255, 130, 199, 85),
                              Color(0xff83f869),
                              Color.fromARGB(255, 166, 253, 112),
                              Color(0xff83f869),
                              // Colors.yellow.shade100,
                              // Colors.orangeAccent.shade200,
                              // Colors.yellow.shade300,
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              top: 25, bottom: 25, right: 8, left: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              //Column for available balance
                              Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: [
                                      const Text(
                                        'Available Balance',
                                        style: TextStyle(
                                            fontSize: 17, fontWeight: FontWeight.normal),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  walletAmount == null
                                      ? Row(
                                          children: [
                                            const Icon(Icons.currency_rupee_sharp),
                                            Text(' ',
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 27,
                                                    fontWeight: FontWeight.bold))
                                          ],
                                        )
                                      : Row(
                                          children: [
                                            const Icon(Icons.currency_rupee_sharp),
                                            Text('${walletAmount}',
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 27,
                                                    ))
                                          ],
                                        )
                                ],
                              ),
                              //Container for credit button
                              Align(
                                alignment: Alignment.bottomRight,
                                child: ElevatedButton(
                                  key: const Key('creditButton'),
                                  style: ElevatedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    backgroundColor: Colors.white,

                                    // const Color.fromARGB(255, 130, 199, 85),
                                    elevation: 5, // set the elevation value
                                  ),
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => AddMoneyScreen(
                                                  userId: widget.userId,
                                                )));
                                  },
                                  child: const Text(
                                    'Credit',
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ),

                  //Container for transaction heading
                  Container(
                    decoration:
                        const BoxDecoration(color: Color.fromARGB(255, 130, 199, 85)),
                    child: Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: Center(
                          child: Text(
                        'Transactions',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                            fontSize: MediaQuery.of(context).size.width * 0.06),
                      )),
                    ),
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      credit
                          ? Container(
                              width: MediaQuery.of(context).size.width / 2,
                              padding: const EdgeInsets.all(8.0),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(width: 2, color: Colors.green),
                                ),
                              ),
                              child: Center(
                                  child: const Text("Credit",
                                      style: TextStyle(
                                        fontSize: 17,
                                      ))))
                          : InkWell(
                              onTap: () {
                                setState(() {
                                  newTransactionData = [];
                                  // getTransaction();
                                  credit = true;
                                });
                              },
                              child: Container(
                                  width: MediaQuery.of(context).size.width / 2,
                                  padding: const EdgeInsets.all(8.0),
                                  child: Center(
                                      child: const Text("Credit",
                                          style: TextStyle(
                                              fontSize: 17, color: Colors.black))))),
                      credit
                          ? InkWell(
                              onTap: () {
                                newTransactionData = [];
                                getTransaction();
                                setState(() {
                                  credit = false;
                                });
                              },
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                padding: const EdgeInsets.all(8.0),
                                child: Center(
                                  child: const Text(
                                    "Debit",
                                    style:
                                        TextStyle(fontSize: 17, color: Colors.black),
                                  ),
                                ),
                              ))
                          : Container(
                              width: MediaQuery.of(context).size.width / 2,
                              padding: const EdgeInsets.all(8.0),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(width: 2, color: Colors.green),
                                ),
                              ),
                              child: Center(
                                  child: const Text("Debit",
                                      style: TextStyle(
                                        fontSize: 17,
                                      )))),
                    ],
                  ),
                  //Container for listview
                  Container(
                    height: MediaQuery.of(context).size.height * 0.52,
                    margin: EdgeInsets.all(MediaQuery.of(context).size.width * 0.015),
                    child: newTransactionData.isEmpty
                        ? Center(
                      child: TweenAnimationBuilder(
                        duration: const Duration(seconds: 2),
                        tween: Tween(begin: 0.0, end: 1.0),
                        builder: (context, value, _) => SizedBox(
                          height: 40,
                          width: 40,
                          child: CircularProgressIndicator(
                            value: value,
                            color: Components.lightGreen,
                            backgroundColor: Components.white,
                            strokeWidth: 5,
                          ),
                        ),
                      ),
                    )
                        : Align(
                            alignment: Alignment.topCenter,
                            child: SingleChildScrollView(
                              physics: ScrollPhysics(),
                              child: Column(
                                children: [
                                  //today
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 5.0),
                                    child: Container(
                                      alignment: Alignment.center,
                                      color: Colors.green,
                                      height: 25,
                                      width: MediaQuery.of(context).size.width,
                                      child: Text(
                                        "Today",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 17),
                                      ),
                                    ),
                                  ),
                                  todayTransactionData.isNotEmpty
                                      ?  RefreshIndicator(
                                    key: refreshkey,
                                    onRefresh: ()async{setState(() {
                                      getWalletDetails();
                                    });
                                    print("refresh");
                                    },
                                        child: ListView.builder(
                                            physics: NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            reverse: true,
                                            itemCount: todayTransactionData.length,
                                            itemBuilder: (context, index) {
                                              return Column(
                                                children: [
                                                  Row(
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets.all(8.0),
                                                        child: Container(
                                                            height: 40,
                                                            width: 40,
                                                            child: Center(
                                                                child: Image.asset(
                                                                    "assets/images/debitmoney.png"))),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 8.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Paid to',
                                                              style: TextStyle(
                                                                color: Colors.green,
                                                                // fontWeight: FontWeight.bold,
                                                                fontSize: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.05,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets.only(
                                                                      top: 4.0),
                                                              child: Text(
                                                                "${todayTransactionData[index].chargerName}",
                                                                style: TextStyle(
                                                                    color: Colors.black,
                                                                    fontSize: 17),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                            "${DateFormat('MMMM d, yyyy').format(DateFormat('yyyy-MM-dd').parse("${todayTransactionData[index].transactionMeterStopTimeStamp!}"))}",
                                                            style: TextStyle(
                                                              color: Colors.grey,
                                                              fontSize:
                                                                  MediaQuery.of(context)
                                                                          .size
                                                                          .width *
                                                                      0.035,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets.only(
                                                                    top: 10.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment.end,
                                                              children: [
                                                                Icon(
                                                                  Icons.currency_rupee,
                                                                  size: 20,
                                                                ),
                                                                Text(
                                                                  '${todayTransactionData[index].transactionAmount!.toStringAsFixed(2)}',
                                                                  style: TextStyle(
                                                                      fontSize: 20),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Divider(
                                                    color: Colors.grey,
                                                  )
                                                ],
                                              );
                                            }),
                                      )
                                      : Container(
                                          child: Text("No Transaction For Today")),

                                  //week
                                  Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 5.0, top: 5.0),
                                    child: Container(
                                      alignment: Alignment.center,
                                      color: Colors.green,
                                      height: 25,
                                      width: MediaQuery.of(context).size.width,
                                      child: Text(
                                        "${currentMonth}",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 17),
                                      ),
                                    ),
                                  ),
                                  weekTransactionData.isNotEmpty
                                      ?  RefreshIndicator(
                                    key: refreshkey,
                                    onRefresh: ()async{setState(() {
                                      getWalletDetails();
                                    });
                                    print("refresh");
                                    },
                                        child: ListView.builder(
                                            physics: NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            reverse: true,
                                            itemCount: weekTransactionData.length,
                                            itemBuilder: (context, index) {
                                              return Column(
                                                children: [
                                                  Row(
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets.all(8.0),
                                                        child: Container(
                                                            height: 40,
                                                            width: 40,
                                                            child: Center(
                                                                child: Image.asset(
                                                                    "assets/images/debitmoney.png"))),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 8.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Paid to',
                                                              style: TextStyle(
                                                                color: Colors.green,
                                                                // fontWeight: FontWeight.bold,
                                                                fontSize: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.05,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets.only(
                                                                      top: 4.0),
                                                              child: Text(
                                                                "${weekTransactionData[index].chargerName}",
                                                                style: TextStyle(
                                                                    color: Colors.black,
                                                                    fontSize: 17),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                            "${DateFormat('MMMM d, yyyy').format(DateFormat('yyyy-MM-dd').parse("${weekTransactionData[index].transactionMeterStopTimeStamp!}"))}",
                                                            style: TextStyle(
                                                              color: Colors.grey,
                                                              fontSize:
                                                                  MediaQuery.of(context)
                                                                          .size
                                                                          .width *
                                                                      0.035,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets.only(
                                                                    top: 10.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment.end,
                                                              children: [
                                                                Icon(
                                                                  Icons.currency_rupee,
                                                                  size: 20,
                                                                ),
                                                                Text(
                                                                  '${weekTransactionData[index].transactionAmount!.toStringAsFixed(2)}',
                                                                  style: TextStyle(
                                                                      fontSize: 20),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Divider(
                                                    color: Colors.grey,
                                                  )
                                                ],
                                              );
                                            }),
                                      )
                                      : Container(
                                          child:
                                              Text("No Transaction For This Month")),

                                  //month
                                  Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 5.0, top: 5.0),
                                    child: Container(
                                      alignment: Alignment.center,
                                      color: Colors.green,
                                      height: 25,
                                      width: MediaQuery.of(context).size.width,
                                      child: Text(
                                        "Month",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 17),
                                      ),
                                    ),
                                  ),
                                  monthTransactionData.isNotEmpty
                                      ?  RefreshIndicator(
                                    key: refreshkey,
                                    onRefresh: ()async{setState(() {
                                      getWalletDetails();
                                    });
                                    print("refresh");
                                    },
                                        child: ListView.builder(
                                            physics: NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            reverse: true,
                                            itemCount: monthTransactionData.length,
                                            itemBuilder: (context, index) {
                                              return Column(
                                                children: [
                                                  Row(
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets.all(8.0),
                                                        child: Container(
                                                            height: 40,
                                                            width: 40,
                                                            child: Center(
                                                                child: Image.asset(
                                                                    "assets/images/debitmoney.png"))),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 8.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Paid to',
                                                              style: TextStyle(
                                                                color: Colors.green,
                                                                // fontWeight: FontWeight.bold,
                                                                fontSize: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.05,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets.only(
                                                                      top: 4.0),
                                                              child: Text(
                                                                "${monthTransactionData[index].chargerName}",
                                                                style: TextStyle(
                                                                    color: Colors.black,
                                                                    fontSize: 17),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                            "${DateFormat('MMMM d, yyyy').format(DateFormat('yyyy-MM-dd').parse("${monthTransactionData[index].transactionMeterStopTimeStamp!}"))}",
                                                            style: TextStyle(
                                                              color: Colors.grey,
                                                              fontSize:
                                                                  MediaQuery.of(context)
                                                                          .size
                                                                          .width *
                                                                      0.035,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets.only(
                                                                    top: 10.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment.end,
                                                              children: [
                                                                Icon(
                                                                  Icons.currency_rupee,
                                                                  size: 20,
                                                                ),
                                                                Text(
                                                                  '${monthTransactionData[index].transactionAmount!.toStringAsFixed(2)}',
                                                                  style: TextStyle(
                                                                      fontSize: 20),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Divider(
                                                    color: Colors.grey,
                                                  )
                                                ],
                                              );
                                            }),
                                      )
                                      : Container(
                                          child: Text("No Transaction For Month")),

                                  //year
                                  Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 5.0, top: 5.0),
                                    child: Container(
                                      alignment: Alignment.center,
                                      color: Colors.green,
                                      height: 25,
                                      width: MediaQuery.of(context).size.width,
                                      child: Text(
                                        "Year",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 17),
                                      ),
                                    ),
                                  ),
                                  yearTransactionData.isNotEmpty
                                      ?  RefreshIndicator(
                                    key: refreshkey,
                                    onRefresh: ()async{setState(() {
                                      getWalletDetails();
                                    });
                                    print("refresh");
                                    },
                                        child: ListView.builder(
                                            physics: NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            reverse: true,
                                            itemCount: yearTransactionData.length,
                                            itemBuilder: (context, index) {
                                              return Column(
                                                children: [
                                                  Row(
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets.all(8.0),
                                                        child: Container(
                                                            height: 40,
                                                            width: 40,
                                                            child: Center(
                                                                child: Image.asset(
                                                                    "assets/images/debitmoney.png"))),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 8.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Paid to',
                                                              style: TextStyle(
                                                                color: Colors.green,
                                                                // fontWeight: FontWeight.bold,
                                                                fontSize: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.05,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets.only(
                                                                      top: 4.0),
                                                              child: Text(
                                                                "${yearTransactionData[index].chargerName}",
                                                                style: TextStyle(
                                                                    color: Colors.black,
                                                                    fontSize: 17),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                            "${DateFormat('MMMM d, yyyy').format(DateFormat('yyyy-MM-dd').parse("${yearTransactionData[index].transactionMeterStopTimeStamp!}"))}",
                                                            style: TextStyle(
                                                              color: Colors.grey,
                                                              fontSize:
                                                                  MediaQuery.of(context)
                                                                          .size
                                                                          .width *
                                                                      0.035,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets.only(
                                                                    top: 10.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment.end,
                                                              children: [
                                                                Icon(
                                                                  Icons.currency_rupee,
                                                                  size: 20,
                                                                ),
                                                                Text(
                                                                  '${yearTransactionData[index].transactionAmount!.toStringAsFixed(2)}',
                                                                  style: TextStyle(
                                                                      fontSize: 20),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Divider(
                                                    color: Colors.grey,
                                                  )
                                                ],
                                              );
                                            }),
                                      )
                                      : Container(
                                          child: Text("No Transaction For Year")),
                                ],
                              ),
                            ),
                          ),
                  ),
                ],
              ),
      ),
    );
  }
}
