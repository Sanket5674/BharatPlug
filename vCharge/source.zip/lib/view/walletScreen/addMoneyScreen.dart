import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../connectivity_service.dart';

// ignore: must_be_immutable
class AddMoneyScreen extends StatefulWidget {
  String? userId;

  AddMoneyScreen({required this.userId, super.key});

  @override
  State<StatefulWidget> createState() => AddMoneyScreenState();
}

class AddMoneyScreenState extends State<AddMoneyScreen> {
  //this amount is initial amount in text field
  String initialAmount = "1000";
  final ConnectivityService _connectivityService = ConnectivityService();

  var amountController = TextEditingController();

  Razorpay? _razorpay;

  @override
  void initState() {
    super.initState();
    amountController.text = initialAmount;
    _razorpay = Razorpay();
    _razorpay?.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay?.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay?.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay?.clear();
    amountController.dispose();
    _checkConnectivity();
  }

  Future<void> _checkConnectivity() async {
    final connectivityResult = await _connectivityService.checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('No Internet Connection'),
            content:
                Text('Please check your internet connection and try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );

      final snackBar = SnackBar(
        content: Text('No internet connection'),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      return;
    }
  }

  void addToAmountController(int amount) {
    setState(() {
      if (amountController.text.isNotEmpty) {
        int addedAmount = int.parse(amountController.text) + amount;
        amountController.text = addedAmount.toString();
      } else {
        amountController.text = amount.toString();
      }
    });
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    Fluttertoast.showToast(
        msg: "Payment Successful: ${response.paymentId!}",
        timeInSecForIosWeb: 4);
    _addTransactionHistoryItem(
      amountController.text,
      "vCharge",
      "Adding Money to Wallet",
      true,
      response.paymentId!,
    );
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
        msg: "Payment Error: ${response.code} - ${response.message}",
        timeInSecForIosWeb: 4);
    _addTransactionHistoryItem(
      amountController.text,
      "vCharge",
      "Adding Money to Wallet",
      false,
      null,
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "External Wallet: ${response.walletName}", timeInSecForIosWeb: 4);
  }

  void _addTransactionHistoryItem(String amount, String name,
      String description, bool isSuccess, String? orderId) async {
    String formattedTime =
        DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());

    final prefs = await SharedPreferences.getInstance();
    final transactionHistoryJson =
        prefs.getStringList('transactionHistory') ?? [];

    transactionHistoryJson.add(json.encode({
      'amount': amount,
      'name': name,
      'description': description,
      'isSuccess': isSuccess,
      'time': formattedTime,
      'orderId': orderId ?? '',
    }));

    await prefs.setStringList('transactionHistory', transactionHistoryJson);
  }

  void _startPayment() async {
    const String apiKey = 'rzp_test_tHFJFc8VTTUYD6';
    const String apiSecret = 'duTC6x32h6Ss9KuR3vbk5YTB';
    const String apiUrl = 'https://api.razorpay.com/v1/orders';

    final String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$apiKey:$apiSecret'));

    final Map<String, dynamic> orderData = {
      'amount': int.parse(amountController.text) * 100,
      'currency': 'INR',
      'receipt': 'order_receipt_${DateTime.now().millisecondsSinceEpoch}',
    };

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': basicAuth,
      },
      body: json.encode(orderData),
    );

    if (response.statusCode == 200) {
      final orderResponse = json.decode(response.body);
      String orderId = orderResponse['id'];

      var options = {
        'key': apiKey,
        'amount': int.parse(amountController.text),
        'order_id': orderId,
        'name': 'vCharge',
        'description': 'Adding Money to Wallet',
      };
      print(orderId);

      _razorpay?.open(options);
    } else {
      throw Exception('Failed to create Razorpay order');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: GestureDetector(
        onTap: () {
          // Remove focus from text field when the user taps outside
          FocusScope.of(context).unfocus();
        },
        child: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: const Text('Wallet'),
          ),
          body: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                //container for image
                Container(
                  margin:
                      EdgeInsets.all(MediaQuery.of(context).size.width * 0.05),
                  // width: MediaQuery.of(context).size.width * 0.95,
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: SvgPicture.asset('assets/images/addMoney.svg'),
                ),

                // Title text -> Add Money to Wallet
                Container(
                  margin: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.05),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Text(
                          'Add Money To Wallet',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              fontSize:
                                  MediaQuery.of(context).size.width * 0.05,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),

                // container for amount input
                Container(
                  margin: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.03,
                      right: MediaQuery.of(context).size.width * 0.03),
                  child: Card(
                    child: Column(
                      children: [
                        //Container for text field
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Card(
                            elevation: 5,
                            child: TextField(
                              key: const Key('amountTextField'),
                              controller: amountController,
                              style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width * 0.07,
                                  fontWeight: FontWeight.bold),
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Enter Amount',
                                prefixIcon: Icon(Icons.currency_rupee),
                              ),
                            ),
                          ),
                        ),

                        //Row for buttons which add a specific ammount
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              //button for add 100
                              ElevatedButton(
                                  key: const Key('add100Button'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                  ),
                                  onPressed: () {
                                    addToAmountController(100);
                                  },
                                  child: const Text(
                                    '+100',
                                    style: TextStyle(color: Colors.black),
                                  )),

                              //button for add 500
                              ElevatedButton(
                                  key: const Key('add500Button'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                  ),
                                  onPressed: () {
                                    addToAmountController(500);
                                  },
                                  child: const Text(
                                    '+500',
                                    style: TextStyle(color: Colors.black),
                                  )),

                              //button for add 1000
                              ElevatedButton(
                                  key: const Key('add1000Button'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                  ),
                                  onPressed: () {
                                    addToAmountController(1000);
                                  },
                                  child: const Text(
                                    '+1000',
                                    style: TextStyle(color: Colors.black),
                                  )),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Proceed to Add Button
                GestureDetector(
                  key: const Key('proceedToAddButton'),
                  onTap: () {
                    _startPayment();
                  },
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width * 0.94,
                    child: Card(
                      color: const Color.fromARGB(255, 130, 199, 85),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            'Proceed to Add',
                            style: TextStyle(
                              fontSize:
                                  MediaQuery.of(context).size.width * 0.048,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
