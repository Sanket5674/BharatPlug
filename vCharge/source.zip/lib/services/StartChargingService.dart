import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:vcharge/services/urls.dart';
import 'package:vcharge/view/components.dart';

import '../view/startChargingScreen/startChargingScreen.dart';

class StartChargingService {
  late BuildContext context;
  StartChargingService(BuildContext context) {
    this.context = context;
  }

  startChargingApiCall(
      String userId,
      String idTag,
      String connectorNumber,
      String chargerSerialNumber,
      int amount,
      int minutes,
      double unit,
      String modeOfCharging) async {
    try {
      final requestBody = {
        "userId": userId,
        "idTag": idTag,
        "connectorNumber": connectorNumber,
        "chargerSerialNumber": chargerSerialNumber,
        "amount": amount * 100,
        "minutes": minutes,
        "unit": unit * 1000,
        "modeOfCharging": modeOfCharging
      };

      final requestBodyJson = json.encode(requestBody);

      final apiUrl = Uri.parse(
          '${Urls().baseUrl}8104/ocppServer/remoteStartTransaction');

      final response = await http.post(apiUrl,
          headers: {'Content-Type': 'application/json'}, body: requestBodyJson);

      if (response.statusCode == 200) {
        var status = jsonDecode(response.body);
        print("response is this  : ${response.body} ");
        if (status['status'] != "Charging is already going on" &&
            status['status'] != "unavailable" &&
            status['status'] != "Insufficient Balance" &&
            status['status'] != "Charger unavailable") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => StartChargingScreen(
                        TRNID: status['status'],
                      )));
        } else {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  content: Text('${status['status']}'),
                  actions: [
                    ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: const Text('OK'))
                  ],
                );
              });
        }
      } else {
        Navigator.pop(context);
        Components().showSnackbar(Components().something_want_wrong, context);
      }
    } catch (e) {
      Navigator.pop(context);
      Components().showSnackbar(Components().something_want_wrong, context);
    }
  }
}
