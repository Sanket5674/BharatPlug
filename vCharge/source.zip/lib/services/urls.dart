
class Urls{
  String baseUrl = "http://192.168.0.243:";
  
}