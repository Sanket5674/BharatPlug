// class for storing the latitude and longitude of the markers to be shown on map

class MarkerDetails{
  int? lat;
  int? lng;

  MarkerDetails({
    this.lat,
    this.lng
  });
}