// this is the model for the wallet services

class WalletModel {
  double? walletAmount;
  bool? walletStatus;

  WalletModel({this.walletAmount, this.walletStatus});
}
