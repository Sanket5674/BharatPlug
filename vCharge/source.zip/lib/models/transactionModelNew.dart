class TransactionModelNew {
  String? transactionId;
  double? transactionAmount;
  String? chargerName;
  String? transactionMeterStopTimeStamp;

  TransactionModelNew(
      {this.transactionId,
        this.transactionAmount,
        this.chargerName,
        this.transactionMeterStopTimeStamp,});
}
